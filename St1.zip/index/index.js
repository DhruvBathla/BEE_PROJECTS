const bodyParser = require('body-parser');
const express = require('express');
const fs = require('fs');
var app = express();

app.use(bodyParser.urlencoded({extended:true}))

app.get('/',function(request,response){
    response.sendFile(  __dirname + '/index.html')
})

app.post('/home',function(request,response){
    let name = request.body.Name;
    let id = request.body.id;

    let English = parseInt(request.body.English);
    let Science = parseInt(request.body.Science);
    let sst  =    parseInt(request.body.Social);
    let Maths =   parseInt(request.body.Maths);
    let Hindi =   parseInt(request.body.Hindi);
    let total_marks = English + Science + sst + Maths + Hindi;

    let average = total_marks / 5

    var grade = 'A';
    if(average>=90){
        grade='A';
    }else if(average>=80 && average<90){
        grade='B';
    }else if(average>=70 && average<80){
        grade='C';
    }else if(average>=55 && average<70){
        grade='D';
    }else if(average>=40 && average<55){
        grade='E';
    }else if(average<=33){
        grade='F';
    }

    

    response.write(`<p>Student Name : ${name}`)
    response.write(`<p>Student Id : ${id}`)
    response.write(`<p>English : ${English}`)
    response.write(`<p>Hindi : ${Hindi}`)
    response.write(`<p>Science : ${Science}`)
    response.write(`<p>sst : ${sst}`)
    response.write(`<p>Maths : ${Maths}`)
    response.write(`<p>total_marks : ${total_marks}`)
    response.write(`<p>average : ${average}`)
    response.write(`<p>grade : ${grade}`)

    let scoreCard = {
        'Student Name' : name,
        'Student Id' : id,
        'English' : English,
        'Hindi' : Hindi,
        'Science' : Science,
        'Social Science' : sst,
        'Maths' : Maths,
        'Total Marks' : total_marks,
        'Average Marks' : average,
        'Grade':grade
    }
    
    fs.appendFileSync("data.txt",JSON.stringify(scoreCard));
    // const data = fs.readFileSync("data.txt","utf-8")
    // response.end(data);
    response.end();
})

app.listen(3000,()=>{
    console.log("Server started at 3000.")
})